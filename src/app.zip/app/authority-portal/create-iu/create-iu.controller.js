
 (function() {
   'use strict';

   angular
     .module('testProject')
     .controller('CreateiuController', CreateiuController);

   /** @ngInject */
   function CreateiuController($timeout, $rootScope, $scope, $state) {
     var vm = this;




     }

   }
  )();
