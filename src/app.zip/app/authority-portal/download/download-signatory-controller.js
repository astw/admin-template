/**
 * Created by swang on 9/6/2016.
 */
(function () {
  'use strict';

  angular
    .module('testProject')
    .controller('DownloadsignatoryController', DownloadsignatoryController);


  /* @ngInject */
  function DownloadsignatoryController() {
    var vm = this;
    vm.title = 'Downloadsignatory';

    activate();

    ////////////////

    function activate() {

    }
  }

})();


