/* global malarkey:false, moment:false */
(function() {
  'use strict';

  angular
    .module('testProject')
    .constant('malarkey', malarkey)
    .constant('moment', moment);

})();
