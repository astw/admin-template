(function() {
  'use strict';

  angular
    .module('testProject', [
                            'ngAnimate',
                            'ngStorage',
                            'ngCookies', 'ngTouch', 'ngSanitize', 'ngMessages', 'ngAria', 'ngResource', 'ui.router', 
                            'ui.bootstrap',
                            'toastr',
                            'oitozero.ngSweetAlert',
                            'kendo.directives'
                           ]);

})();
